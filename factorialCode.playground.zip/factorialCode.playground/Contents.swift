//first we use a loop and after that we use a recurtion

import UIKit

func factorialOfValue(value: Int) -> Int {
    
    if value == 0 {
        return 1
    }
    
    var product: Int = 1
    for i in 1...value {
        product = product * i
//    print(i)
        
    }
    return product
}

func recursiveFactorialOfValue(value: Int) -> Int {
    
    if value == 0 {
        return 1
    }
    
    print(value)
    
    return value * recursiveFactorialOfValue(value - 1)
}

//print(factorialOfValue(value: 3))
//factorialOfValue(5)
recursiveFactorialOfValue(100)
